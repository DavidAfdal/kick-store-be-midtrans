langkah - langkah menajalankan program :
1. Pastikan sudah menginstall node js dan docker desktop.
2. Git clone / download repository ini.
3. Buka file tersebut di vscode dan diterminal ketikan docker-compose up -d
4. Setelah docker berhasil dijalankan kemudian jalankan code server dengan mengetikan npm run dev diterminal.
 



