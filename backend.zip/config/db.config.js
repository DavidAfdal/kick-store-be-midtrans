import { Sequelize } from 'sequelize';

const sequelize = new Sequelize({
  dialect: 'mysql',
  host: 'api.kickstore.cloud',
  username: 'kick7994_david',
  password: '$Bn]~RK=CsXE ',
  database: 'kick7994_kick_store',
  logging: false
});

// const sequelize = new Sequelize("https://leewmwaylxnmtjdhuydq.supabase.co", {})

export default sequelize;
